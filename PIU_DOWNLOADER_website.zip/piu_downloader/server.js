const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, "public");
const MIME = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".svg": "image/svg+xml" };

const server = http.createServer((req, res) => {
  if (req.method === "POST" && req.url === "/api/resolve") {
    let body = "";
    req.on("data", chunk => body += chunk);
    req.on("end", () => {
      let input;
      try { input = JSON.parse(body || "{}"); } catch {
        res.writeHead(400, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ error: "Invalid request." }));
      }
      const url = String(input.url || "").trim();
      const allowed = /^https?:\/\/(www\.)?(tiktok\.com|vm\.tiktok\.com|facebook\.com|fb\.watch|instagram\.com)\//i.test(url);
      if (!allowed) {
        res.writeHead(400, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ error: "Please enter a valid public TikTok, Facebook, or Instagram link." }));
      }
      // Connect an authorized provider API here. Do not scrape private content,
      // bypass access controls, or download content without permission.
      res.writeHead(501, { "Content-Type": "application/json" });
      res.end(JSON.stringify({
        error: "Download service is not connected yet.",
        detail: "The website interface is ready. Connect an authorized provider/API that supports public content and respects creator rights and platform terms."
      }));
    });
    return;
  }

  const pathname = decodeURIComponent((req.url || "/").split("?")[0]);
  const requested = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const file = path.resolve(PUBLIC, requested);
  if (!file.startsWith(PUBLIC + path.sep)) {
    res.writeHead(403); return res.end("Forbidden");
  }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream" });
    res.end(data);
  });
});

server.listen(PORT, () => console.log(`PIU DOWNLOADER running at http://localhost:${PORT}`));
