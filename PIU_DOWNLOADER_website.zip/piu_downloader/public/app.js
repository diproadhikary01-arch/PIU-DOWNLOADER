const form = document.getElementById("downloadForm");
const input = document.getElementById("videoUrl");
const statusBox = document.getElementById("status");
const button = document.getElementById("submitBtn");
document.getElementById("year").textContent = new Date().getFullYear();

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  statusBox.hidden = false;
  statusBox.className = "status";
  statusBox.textContent = "Checking link…";
  button.disabled = true;
  try {
    const response = await fetch("/api/resolve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: input.value.trim() })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not check this link.");
    throw new Error(data.detail || data.error || "No download options available.");
  } catch (error) {
    statusBox.className = "status error";
    statusBox.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
